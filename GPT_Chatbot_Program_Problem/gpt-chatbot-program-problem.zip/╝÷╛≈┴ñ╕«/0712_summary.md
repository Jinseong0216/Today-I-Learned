# **Start Camp 3일차**

- 오늘 할 내용
    - pull(이미 local에 있을 때)
    - clone(local에 없을 때)
    - remote repository
    - How to roll-back


## 원격 저장소
- 코드와 버전 관리 이력을 온라인 상의 특정 위치에 저장하여

    여러 개발자가 협업하고 코드를 공유할 수 있는 저장 공간

    원격 저장소 종류: **GitLab**(SSAFY에서 주로 사용), **GitHub**(Major), **Bitbucket**(Minor)


- 원격 저장소 만들기
1. GitHub가입(repository를 main말고 master로 변경)
2. create repository
3. 로컬 저장소에 원격 저장소 추가
    - `git remote add origin remote_repo_url`
    - origin(추가하는 원격저장소 별칭)(일종의 convention)
    - remote_repo_url(원격 저장소 주소)
- **주의사항** - terminal에서 Ctrl v 사용하지말고 shift insert 사용하기
- `git remote -v`
    - fetch 어디서 가지고 올것인가 의미
    - merge를 한번에 해주는 것이 
    - push(로컬 to 원격)
    - pull/clone(원격 to 로컬)
- `git push origin master`
    - 원격 저장소에 commit 목록을 업로드
    - git에게 origin이라는 이름의 원격 저장소에 master라는 이름으로 올려줘라는 의미
    - 입력하면 인증관리 창이 나옴(처음이라)
    - 권한 인증하면 됨
    - 이제 다시 내 github repository에 들어가면 
        기존에 commit했던 파일들이 올라가있는 것을 확인 할 수 있다.